# ShardRCA / Telco RCA Research Artifact

This repository now focuses on **ShardRCA**, an evidence-isolated autonomous
multi-agent root-cause analysis system evaluated with preregistered,
label-safe benchmark protocols. Worker agents form local hypotheses, exchange
peer critiques, revise their posteriors, and then pass an auditable transcript
to fusion/falsification.

## Current Evidence Status

The strongest current result is on RCAEval-Hard:

| Evidence | ShardRCA | Baseline | Result |
|---|---:|---:|---|
| test holdout Hit@1 | 0.60 | 0.20 `single_react_sc` | +0.40, exact paired p=0.007812 |
| fresh holdout Hit@1 | 0.667 | 0.375 `single_react_sc` | +0.292, exact paired p=0.039 |

Claim:

> Evidence-isolated ShardRCA improves root-cause localization over a budgeted single-context ReAct RCA agent on preregistered, label-safe RCAEval-Hard holdouts.

> This does not prove that multi-agent RCA beats every possible single-agent system; the supported claim is limited to budgeted single-context ReAct baselines.

> OpenRCA Telecom is currently **diagnostic/supporting evidence only**. ShardRCA is numerically first in the reviewed run, but the confirmatory gate is underpowered and not claim-ready.

## Architecture Overview

ShardRCA is now an autonomous peer-interaction MAS:

1. **Planner / shard builder** creates label-safe evidence shards by modality,
   component group, topology neighborhood, and time window.
2. **Autonomous investigator agents** inspect only their local shard and emit
   local candidates/posteriors with evidence pointers.
3. **Peer interaction round** lets agents publish proposals, critique other
   agents' candidates, and revise their own posterior without seeing labels.
4. **Correlation-aware fusion** combines revised worker distributions while
   discounting redundant evidence.
5. **Causal rerankers** apply topology coverage and temporal precedence only
   when a separately preregistered validation artifact enables them; the default
   confirmatory path is no-fit/no-op.
6. **Falsifier / refinement** performs targeted top-vs-runner checks before the
   final root-cause answer.
7. **Audit artifacts** record worker distributions, peer transcript, fusion
   candidates, ablations, usage, and label-safety provenance.

The key ablation for the MAS interaction mechanism is `no_interaction`; `no_refinement`,
`no_topology`, and `no_falsifier` isolate later decision stages.

## Install

```bash
make install

# Heavier public benchmark dependencies:
make install-research
```

Set an OpenAI-compatible endpoint when running live LLM benchmarks:

```bash
OPENAI_API_KEY=...
OPENAI_BASE_URL=https://api.openai.com/v1
OPENAI_MODEL=gpt-4o-mini
```

## Useful Commands

```bash
# Run tests
make test

# RCAEval profile/smoke benchmark; override BENCH_ARGS for other suites.
make bench

# Fresh RCAEval confirmatory run
make bench-rcaeval-fresh

# OpenRCA preparation and benchmark flow
scripts/download_openrca_telecom.sh --extract
make prepare-openrca
make prereg-openrca
make bench-openrca-full

# Rebuild readiness and claim audit reports
make readiness
make claim-audit
```

## Report Direction

A research artifact with three pillars:

1. Evidence-isolated autonomous multi-agent RCA architecture with peer critique
   and posterior revision.
2. Preregistered, label-safe benchmark protocol with claim auditing.
3. Replicated RCAEval-Hard win over budgeted single-context ReAct, plus clear boundaries on stronger single-agent systems and real-telecom evidence.


## Repository Map

```text
telco_mas/shardrca/        ShardRCA autonomous agents, interaction, fusion, falsifier, reranking
telco_mas/evaluation/      RCAEval runners, statistics, readiness, claim audit
telco_mas/openrca/         OpenRCA adapters, preparation, runner, analysis
scripts/                  RCAEval/BARO helpers, OpenRCA download helper
```
